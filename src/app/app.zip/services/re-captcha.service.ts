import { Injectable } from '@angular/core';
// import { ReCaptchaV3Service } from 'ng-recaptcha';
import { Observable, Subscription } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ReCAPTCHAService {

  constructor(
    // private _recaptchaV3Service: ReCaptchaV3Service
  ) { }

  // private singleExecutionSubscription?: Subscription = undefined;
  // recentToken = "";

  // executeAction(action: string): Observable<string> {
  //   // if (this.singleExecutionSubscription) {
  //   //   this.singleExecutionSubscription.unsubscribe();
  //   // }
  //   return this._recaptchaV3Service.execute(action);
  // }
}
