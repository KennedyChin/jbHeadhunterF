import { HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { throwError } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ApiServiceService {

  private _baseUrl: string = environment.apiUrl;
  // private _baseUrl: string = "https://www.jbhr.com.tw/178/api";

  constructor() { }

  public get baseUrl(): string {
    return this._baseUrl;
  }

  public baseAuthHeader(token:string,context_type?:string):any {
    return  {
      'content-type': context_type??'application/json',
      'Authorization': `Bearer ${token}`
    }
  }

  /**
 * 錯誤紀錄點1
 * @param errorRes 
 * @returns 
 */
  public handleError(errorRes: HttpErrorResponse) {
    let errorMessage = "未知的錯誤";
    if (!errorRes.error) {
      // if (!errorRes.error || !errorRes.error.error) {
      return throwError(errorMessage);
    }
    errorMessage = errorRes.error.message;
    return throwError(errorMessage);
  }
}
