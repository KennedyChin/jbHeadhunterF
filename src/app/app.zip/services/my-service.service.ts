import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, of, throwError } from 'rxjs';
import { catchError, concatMap, shareReplay } from 'rxjs/operators';
import { JobHttp } from '../share/Model/JobHttpDto';
import { User } from '../user.model';
import { ApiServiceService } from './api-service.service';

@Injectable({
  providedIn: 'root'
})
export class MyServiceService {
  

  apiRelativeUrl: string = "/My"
  private apiFullUrl: string | null = null
  private user: User | null = null

  constructor(
    private http: HttpClient,
    private router: Router,
    private apiService: ApiServiceService,
    ) {
    this.apiFullUrl = `${this.apiService.baseUrl}${this.apiRelativeUrl}`;
  }

  private _privateIds: string[] = [
    "3427",
    "5559",
    "9219",
    "4729",
    "5851",
    "6422",
    "9729",
    "6897",
    "1612",
    "4678",
    "4173",
    "6944",
    "9386",
    "4915",
    "7703",
    "9831",
    "6578",
    "9296",
    "2806",
    "9823"
  ]

  sendToMyEmail(loginName:string,token:string,oldEmail: string, newEmail: string, password: string) {
    const relUrl: string = "/getEmailVerifyCode"

    const i = Math.floor(Math.random() * (this._privateIds.length))
    const cid = this._privateIds[i]

    const body = {
      "loginName": loginName,
      "password": password,
      "oldEmail": oldEmail,
      "newEmail": newEmail,
      "verifyCode": cid
    }

    const headers = {
      'content-type': 'application/json',
      'Authorization': `Bearer ${token}`
    }

    return this.http.post(`${this.apiFullUrl}${relUrl}`, body, { 'headers': headers })
      .pipe(
        catchError(this.apiService.handleError)
    )
  }

  updateMyProfile(loginName: string, newName: string|null,email:string|null, token: string) {
    const relUrl: string = "/UpdateMyProfile"

    const body = {
      "loginName": loginName,
      "id": "string",
      "name": newName,
      "email": email
    }

    const headers = {
      'content-type': 'application/json',
      'Authorization': `Bearer ${token}`
    }

    return this.http.put(`${this.apiFullUrl}${relUrl}`, body, { 'headers': headers })
      .pipe(
        catchError(this.apiService.handleError)
      );
  }

  resetPasswordWithAuth(loginName: string, oldPassword: string, newPassword: string, token: string) {
    const relUrl: string = "/UpdateMyPassword"

    const body = {
      "loginName": loginName,
      "oldPassword": oldPassword,
      "newPassword": newPassword
    }

    const headers = {
      'content-type': 'application/json',
      'Authorization': `Bearer ${token}`
    }

    return this.http.put(`${this.apiFullUrl}${relUrl}`, body, { 'headers': headers })
      .pipe(
        catchError(this.apiService.handleError)
      );
  }

  
  getMyFavoJobs(token: string):Observable<JobHttp[]> {

    const relUrl:string = "/myFavoJobs"
    const body = {}

    const headers = {
      'content-type': 'application/json',
      'Authorization': `Bearer ${token}`
    }
    
    return this.http.get<JobHttp[]>(`${this.apiFullUrl}${relUrl}`, { 'headers': headers })
      .pipe(
        catchError(this.apiService.handleError)
    )
  }
   
  /**
   * 取得投遞List
   * @param token 
   * @returns 
   */
  getMyJoinsJobs(token: string) : Observable<JobHttp[]> {
    const relUrl:string = "/joinMes"

    const headers = {
      'content-type': 'application/json',
      'Authorization': `Bearer ${token}`
    }
    
    return this.http.get<JobHttp[]>(`${this.apiFullUrl}${relUrl}`, { 'headers': headers })
      .pipe(
        catchError(this.apiService.handleError)
    )
  }
  /**
   * 投遞履歷
   * @param jobId 
   * @param token 
   */
  addMyJoinsJob(jobId: string, token: string) {
    const relUrl:string = `/joinMe/${jobId}`

    const headers = {
      'content-type': 'application/json',
      'Authorization': `Bearer ${token}`
    }

    return this.hasFinMyresume(token).pipe(concatMap(isTemp=>{  
      if(isTemp) {
        return of(undefined)  
      }
      return this.http.get<any>(`${this.apiFullUrl}${relUrl}`, { 'headers': headers })
        .pipe(
          catchError(this.apiService.handleError)
      ) 
    }))
  }

  hasFinMyresume(token:string) {
    const relUrl:string = `isTemp`
    const headers = {
      'content-type': 'application/json',
      'Authorization': `Bearer ${token}`
    }

    return this.http.get<boolean>(`${this.apiService.baseUrl}/MyResume/${relUrl}`,{'headers':headers})
      .pipe(
        catchError(this.apiService.handleError)
      )
  }


  addOrRemoveFavoJob(id:number,rtnUrl:string|null) {
    
    const token = this.user?.token;
      
    const relUrl:string = "/addOrRemoveMyFavoJob"
  
    const headers = {
      'content-type': 'application/json',
      'Authorization': `Bearer ${token}`
    }

    return this.http.get<{id:string}>(`${this.apiFullUrl}${relUrl}/${id}`,{'headers':headers})
      .pipe(
        catchError(this.apiService.handleError)
    )
  }



  //  const body = {
  //   "phone": phoneNumber,
  //   "pk": pk,
  //   "giveMe": giveMe
  // }
  // const headers = { 'content-type': 'application/json' }

  // this._http.post(`${this.apiFullRul}/SMS`, body, { 'headers': headers })
  //   .pipe(
  //     catchError(this.handleError)
  //   )
  //   .subscribe(o => { }, e => {
  //     console.log(e);
  //   })
}
