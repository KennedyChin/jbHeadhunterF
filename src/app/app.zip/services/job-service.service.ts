import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, shareReplay } from 'rxjs';

import { JobHttp } from '../share/Model/JobHttpDto';
import { User } from '../user.model';
import { ApiServiceService } from './api-service.service';

import { of, tap, map } from 'rxjs';
import { JobsComponent } from '../ui/jobs/jobs.component';
import { BehaviorSubject } from 'rxjs';
import { DATE } from 'ngx-bootstrap/chronos/units/constants';

@Injectable({
  providedIn: 'root'
})
export class JobServiceService {
    
  // 宣告並初始化 savedJobsCount 屬性
  savedJobsCount: number = 0; 

  resultDataList: any;
  resultDataDetail: any;

  private relUrl: string = "/Job"
  private apiFullUrl: string | null = null
  private user: User | null = null

  private savedJobsCountSource = new BehaviorSubject<number>(0);

  savedJobsCount$ = this.savedJobsCountSource.asObservable();

  // 更新收藏職缺數量
  updateSavedJobsCount(count: number) {
    this.savedJobsCountSource.next(count);
  }

  constructor(
    private apiSer: ApiServiceService
    , private http: HttpClient) {
  }

  /**
   * 取得職缺資訊
   * @param num Id
   * @returns 
   */
  getJobDetail(id: number):Observable<JobHttp> {
    const token = this.user?.token??""
    const headers = {
      'content-type': 'application/json',
      // 'Authorization': `Bearer ${token}`
      
      'Authorization': 'Authorization'
    }

    const testData: JobHttp = 
      { 
        id: 2,
        jobName: 'jobname_test',
        companY_JOB_ID: 123,
        whereToDo: 'Zhongli',
        jobCondition: '123',
        jobContent: 'Content'
      }
    ;
    
    const relUrl:string = '/GetActiveJobs'
    const fUrl:string = `https://edc.jbhr.com.tw/FlyHigh/flyMe/Job/GetJobDetial/${id}`
    
    return this.http.get(fUrl).pipe(tap(n => this.resultDataDetail = n), map(() => this.resultDataDetail));  

  }

  ///
  getActiveJobs():Observable<JobHttp[]> {
    const token = this.user?.token??""

    const headers = {
      'content-type': 'application/json',
      'Authorization': `Bearer ${token}`
    }

    const relUrl:string = '/GetActiveJobs'
    return this.http.get<JobHttp[]>(`${this.apiFullUrl}${relUrl}`,{headers:headers})
    // return this.http.get<JobHttp[]>(fUrl,{headers:headers})
    
    // return of(testData);
  }

  // getActiveJobsWithAuth():Observable<JobHttp[]> {
  //   const relUrl:string = '/'
  //   return this.http.get<JobHttp[]>(`${this.apiFullUrl}${relUrl}`)

  // }

  /**
   * 取得搜索職缺
   * @param text 搜索內容
   * @returns 職缺
   */
  getSearchJobs(placeId:number, jobId:number, text:string) {
    const encodeStr:string = encodeURIComponent(text);
    // const token = this.user?.token??""

    const headers = {
      'content-type': 'application/json',
      // 'Authorization': `Bearer ${token}`
      'Authorization': 'Authorization'
    }

    const fUrl:string = `https://edc.jbhr.com.tw/FlyHigh/flyMe/Job/Search/${jobId}/${placeId}/${encodeStr}`
    
    return this.http.get<JobHttp[]>(fUrl);  
  }

  /**
   * 取得電子報職缺
   * @param text 搜索內容
   * @returns 職缺
   */
  getUserNoJobs(userNo:number) {
    const headers = {
      'content-type': 'application/json',
      // 'Authorization': `Bearer ${token}`
      'Authorization': 'Authorization'
    }

    const fUrl:string = `https://edc.jbhr.com.tw/FlyHigh/flyMe/Job/GetMoreMore/${userNo}`
    
    return this.http.get<JobHttp[]>(fUrl);  
  }

  // 在收藏職缺時呼叫的方法
  onJobFavorited(job: JobHttp) {
    // 更新相應的數據

    // 取得 Local Storage 中已儲存的陣列（假設 key 為 'jobs'）
    let savedJobsIds = JSON.parse(localStorage.getItem('jobs')!) || [];

    // 判斷職缺是否已經被使用者收藏
    const jobIndex = savedJobsIds.indexOf(job.id);

    // 如果收藏，且職缺 ID 不在陣列中，則將職缺 ID 加入陣列
    if (jobIndex === -1) {
      savedJobsIds.push(job.id);
    }
    // 如果取消收藏，且職缺 ID 在陣列中，則從陣列中刪除職缺 ID
    else if (jobIndex !== -1) {
      savedJobsIds.splice(jobIndex, 1);
    }

    // 更新 Local Storage 中的值
    localStorage.setItem('jobs', JSON.stringify(savedJobsIds));

    // 更新組件屬性 savedJobsCount
    this.savedJobsCount = savedJobsIds.length;
  }
}
