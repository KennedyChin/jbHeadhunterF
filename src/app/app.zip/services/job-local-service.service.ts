import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, shareReplay } from 'rxjs';

import { JobHttp } from '../share/Model/JobHttpDto';
import { User } from '../user.model';
import { ApiServiceService } from './api-service.service';
import { BehaviorSubject } from 'rxjs';

import { of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class JobLocalServiceService {

  // 宣告並初始化 savedJobsCount 屬性
  savedJobsCount: number = 0; 

  private relUrl: string = "/Job"
  private apiFullUrl: string | null = null
  private user: User | null = null

  private savedJobsCountSource = new BehaviorSubject<number>(0);

  savedJobsCount$ = this.savedJobsCountSource.asObservable();

  constructor(
    private apiSer: ApiServiceService
    , private http: HttpClient) {
  }

  // 更新收藏職缺數量
  updateSavedJobsCount(count: number) {
    this.savedJobsCountSource.next(count);
  }
  /**
   * 取得職缺資訊
   * @param num Id
   * @returns 
   */
  getJobDetail(id: number):Observable<JobHttp> {
    const token = this.user?.token??""
    const headers = {
      'content-type': 'application/json',
      // 'Authorization': `Bearer ${token}`
      
      'Authorization': 'Authorization'
    }

    const testData: JobHttp = 
      { 
        id: 2,
        jobName: 'jobname_test3',
        companY_JOB_ID: 123,
        whereToDo: 'Taipei',
        jobCondition: null,
        jobContent: null
      }
    ;
    
    const relUrl:string = '/GetActiveJobs'
    // const fUrl:string = `${this.apiFullUrl}/GetJobDetail/${id}`

    // return this.http.get<JobHttp>(fUrl,{headers:headers})  
    return of(testData);
  }

  ///
  getSavedJobs():Observable<JobHttp[]> {
    const token = this.user?.token??""

    const headers = {
      'content-type': 'application/json',
      'Authorization': `Bearer ${token}`
    }


    const savedData: JobHttp[] = []

    const jobs: number[] = JSON.parse(localStorage.getItem('jobs')!);

    const url = 'https://edc.jbhr.com.tw/FlyHigh/flyMe/Job/GetJobDetial/';

    // 分別將資料抓出來
    jobs.forEach(job => {
      this.http.get<JobHttp>(url+job).subscribe(data => {
        savedData.push(data);
      });
    });
    
    return of(savedData);
  }

  // getActiveJobsWithAuth():Observable<JobHttp[]> {
  //   const relUrl:string = '/'
  //   return this.http.get<JobHttp[]>(`${this.apiFullUrl}${relUrl}`)

  // }

  /**
   * 取得搜索職缺
   * @param text 搜索內容
   * @returns 職缺
   */
  getSearchJobs(text:string) {
    const encodeStr:string = encodeURIComponent(text);
    const token = this.user?.token??""

    const headers = {
      'content-type': 'application/json',
      // 'Authorization': `Bearer ${token}`
      'Authorization': 'Authorization'
    }

    const testData: JobHttp[] = [
      { 
        id: 3,
        jobName: 'jobname_test',
        companY_JOB_ID: 123,
        whereToDo: 'Taipei',
        jobCondition: null,
        jobContent: null
      }
    ];


    const fUrl:string = `${this.apiFullUrl}/GetSearchResult/${encodeStr}`
    // return this.http.get<JobHttp[]>(fUrl,{headers:headers});
    return of(testData);
  }

  
  // 在收藏職缺時呼叫的方法
  onJobFavorited(job: JobHttp) {
    // 更新相應的數據

    // 取得 Local Storage 中已儲存的陣列（假設 key 為 'jobs'）
    let savedJobsIds = JSON.parse(localStorage.getItem('jobs')!) || [];

    // 判斷職缺是否已經被使用者收藏
    const jobIndex = savedJobsIds.indexOf(job.id);

    // 如果收藏，且職缺 ID 不在陣列中，則將職缺 ID 加入陣列
    if (jobIndex === -1) {
      savedJobsIds.push(job.id);
    }
    // 如果取消收藏，且職缺 ID 在陣列中，則從陣列中刪除職缺 ID
    else if (jobIndex !== -1) {
      savedJobsIds.splice(jobIndex, 1);
    }

    // 更新 Local Storage 中的值
    localStorage.setItem('jobs', JSON.stringify(savedJobsIds));

    // 更新組件屬性 savedJobsCount
    this.savedJobsCount = savedJobsIds.length;
  }
}
