import { identifierName } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { JobsComponent } from '../jobs/jobs.component';
import { ToastTestComponent } from '../tset/toast-test/toast-test.component';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {

  constructor(
    private toastr:ToastrService

  ) { }

  gotoPage() {
    // this.toastr.toastrConfig.enableHtml = true
    // this.toastr.toastrConfig.disableTimeOut = true
    this.toastr.info('Info',"title")
    this.toastr.warning('warning','title')
    this.toastr.error('error','title')
    this.toastr.show('show','title')
  }
  itemList:any[] = [];
  selectedItems:any[] = [];
  settings = {};

  ngOnInit(): void {

    


    this.itemList = [
      { "id": 1, "itemName": "India", "category": "asia" },
      { "id": 2, "itemName": "Singapore", "category": "asia pacific" },
      { "id": 3, "itemName": "Germany", "category": "Europe" },
      { "id": 4, "itemName": "France", "category": "Europe" },
      { "id": 5, "itemName": "South Korea", "category": "asia" },
      { "id": 6, "itemName": "Sweden", "category": "Europe" }
    ];

    this.selectedItems = [...this.itemList.filter(p=>[1,6].findIndex(p1=>p1===p.id)>-1 )];

    this.settings = {
      singleSelection: false,
      text: "Select Fields",
      enableCheckAll:false,
      // selectAllText: 'Select All',
      // unSelectAllText: 'UnSelect All',
      searchPlaceholderText: 'Search Fields',
      // enableSearchFilter: true,
      // limitSelection:2,
      badgeShowLimit: 5,
      groupBy: "category"
    };

  }

  
 

  loadDataSet1(){
    this.selectedItems = [];
    this.itemList = [ { "id": 1, "itemName": "Apple", "category": "fruits" },
      { "id": 2, "itemName": "Banana", "category": "fruits" },
      { "id": 5, "itemName": "Tomatoe", "category": "vegetables" },
      { "id": 6, "itemName": "Potatoe", "category": "vegetables" }];
  }
  loadDataSet2(){
    this.selectedItems = [];
    this.itemList = [
      { "id": 1, "itemName": "India", "category": "asia" },
      { "id": 2, "itemName": "Singapore", "category": "asia pacific" },
      { "id": 3, "itemName": "Germany", "category": "Europe" },
      { "id": 4, "itemName": "France", "category": "Europe" },
      { "id": 5, "itemName": "South Korea", "category": "asia" },
      { "id": 6, "itemName": "Sweden", "category": "Europe" }
    ];
  }
  onItemSelect(item: any) {
    console.log(item);
    console.log(this.selectedItems);
  }
  OnItemDeSelect(item: any) {
    console.log(item);
    console.log(this.selectedItems);
  }
  onSelectAll(items: any) {
    console.log(items);
  }
  onDeSelectAll(items: any) {
    console.log(items);
  }
}
