import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-job-preview',
  templateUrl: './job-preview.component.html',
  styleUrls: ['./job-preview.component.css']
})
export class JobPreviewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
