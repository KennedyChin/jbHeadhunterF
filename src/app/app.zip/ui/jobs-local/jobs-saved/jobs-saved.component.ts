import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { first, map, Observable, of, Subscriber } from 'rxjs';
import { JobLocalServiceService } from 'src/app/services/job-local-service.service';
import { JobHttp } from 'src/app/share/Model/JobHttpDto';
import { JobsLocalComponent } from '../jobs-local.component';

@Component({
  selector: 'app-jobs-saved',
  templateUrl: './jobs-saved.component.html',
  styleUrls: ['./jobs-saved.component.css']
})
export class JobsSavedComponent implements OnInit {

  searchText:string|null = null
  jobs$?:Observable<JobHttp[]> 
  @Input() previewMode:boolean = false
  
  constructor(
    private _route:ActivatedRoute
    ,private _router:Router
    ,private _jobService:JobLocalServiceService
  ) { }

  ngOnInit(): void {
    this.queryParamSubscribe()
  }

  getMeInfo(t:string|null) {
    // const t: string | null = n.get(JobsComponent.searchKey)
    // this.searchText = t
    let o = !!t ? this._jobService.getSavedJobs() :this._jobService.getSavedJobs()
    this.jobs$ = o
  }

  /**
   * 取得query param參數並篩選之
   */
  queryParamSubscribe() {
    this._route.queryParamMap.subscribe(n => {
      // const id = n.get("id")
      const id =this._route.snapshot.paramMap.get("id")
      if(id!==null) {
        this.jobs$ = this._jobService.getJobDetail(+id).pipe(first(),map(o=>[o]))
        return
      }

      const t: string | null = n.get(JobsLocalComponent.searchKey)
      this.searchText = t 
      // this.searchText = t
      // let o = !!t ? this._jobService.getSearchJobs(t) :this._jobService.getActiveJobs()
      // this.jobs$ = o
      // this.jobs$ = this.getMeInfo(t)
      let realText = t??'' 

      let ss:HTMLSelectElement[]= [].slice.call(document.getElementsByClassName('quickSelect'))
      ss.filter(e=>{return e.value !== ''}).forEach(e=> realText += ` ${e.value} `) // 接合搜索條件使用空白為每個搜索內容(AND)
      this.getMeInfo(realText)
    })
  }

}
