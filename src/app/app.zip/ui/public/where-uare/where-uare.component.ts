import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-where-uare',
  templateUrl: './where-uare.component.html',
  styleUrls: ['./where-uare.component.css']
})
export class WhereUareComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
