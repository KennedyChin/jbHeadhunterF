import { HttpClient } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
// import { ReCaptchaV3Service } from 'ng-recaptcha';
import { ToastrService } from 'ngx-toastr';
import { Subscription } from 'rxjs';
import { finalize } from 'rxjs/internal/operators/finalize';
import { filter } from 'rxjs/operators';
import { ApiServiceService } from 'src/app/services/api-service.service';
// import { ReCAPTCHAService } from 'src/app/services/re-captcha.service';

@Component({
  selector: 'app-unsubscribe',
  templateUrl: './unsubscribe.component.html',
  styleUrls: ['./unsubscribe.component.css']
})
export class UnsubscribeComponent implements OnInit  {

  isLoading: boolean = false
  // message: string = ""
  @ViewChild("f",{static:false}) f: NgForm | undefined

 

  constructor(
    private router: Router
    ,private route: ActivatedRoute 
    ,private _http:HttpClient
    ,private toastr: ToastrService
    // ,private _recaptchaV3Service: ReCaptchaV3Service
    // ,private _recaptchaService:ReCAPTCHAService
    ,private _appService:ApiServiceService
    ) { 
      this.route.queryParams
      .pipe(filter(p=>p.message))
      .subscribe(params => {
        // this.message = params.message??"";
        this.toastr.info(params.message??'')
      })

    }

  ngOnInit(): void {
  }


  private singleExecutionSubscription?: Subscription = undefined;
  recentToken = "";
  
  executeAction(action: string): void {
    if (this.singleExecutionSubscription) {
      this.singleExecutionSubscription.unsubscribe();
    }

    // this.singleExecutionSubscription = this._recaptchaService.executeAction(action).subscribe({
    //   next:token=>{
    //     this.recentToken = token;
    //     this.loginMe()
    //   },error:error=>{
    //     this.recentToken = "";
    //     this.toastr.error('reCAPTCHA error')
    //   }
    // })
    
    // this.singleExecutionSubscription = this._recaptchaV3Service.execute(action).subscribe(
    //   (token) => {
    //     this.recentToken = token;
    //     this.loginMe()
    //     // this.recentError = undefined;
    //   },
    //   (error) => {
    //     this.recentToken = "";
    //     this.toastr.error('reCAPTCHA error')
    //     // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
    //     // this.recentError = { error };
    //   }
    // )
  }

  isFieldValid(field: string) {
    //this.f?.control.get("password")
    return true
    //return !this.f?.control.get(field)?.valid && this.f?.control.get(field)?.touched;
  }
 
  loginMe() {

    if(!this.f?.valid){
      // this.message = "必填欄位未填寫"
      this.toastr.warning('必填欄位未填寫')
      return 
    }

    const f = this.f
    this.isLoading = true
    const account = f.value.account
    const password = f.value.password
    
  }

  // 取消訂閱
  unsubscribeNews(form: NgForm){

    console.log('test');

    // 郵件
    const usermail = form.value.usermail;

    // Json格式
    const jsonBody = {
      'email': usermail
    };

    const headers = { 'content-type': 'application/json' }

    if (form.valid) {
      // 表單驗證通過，可以提交表單

      const sendUserData$ = this._http.post(
        'https://edc.jbhr.com.tw/FlyHigh/flyMe/NewNewspaper/unsubscribe', jsonBody, { 'headers': headers })
        .pipe(finalize(()=>{}))
  
      sendUserData$.subscribe(n=>console.log(n))
        
      alert('已取消訂閱');
  
      // 將使用者重新導回首頁
      window.location.href = 'https://edc.jbhr.com.tw/FlyHigh/web/'; // 將 URL 設為首頁的 URL

    } 
    else {
      // 表單驗證失敗，阻止提交表單
    }
  }
}
