import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-jobs-main',
  templateUrl: './jobs-main.component.html',
  styleUrls: ['./jobs-main.component.css']
})
export class JobsMainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
