import { Component, EventEmitter, Input, OnInit, Output, TemplateRef } from '@angular/core';
import { Location } from '@angular/common';
import { Clipboard } from '@angular/cdk/clipboard';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { delay, finalize } from 'rxjs/operators';
import { NgxSpinnerService } from "ngx-spinner";

import { JobServiceService } from 'src/app/services/job-service.service';
import { JobHttp } from 'src/app/share/Model/JobHttpDto';
import { MyServiceService } from 'src/app/services/my-service.service';
import { ActivatedRoute, Router, RouterPreloader } from '@angular/router';

import { routesPath } from '../../app-routing.module'
import { Utility } from '../utility';
import { ApiServiceService } from 'src/app/services/api-service.service';
import { User } from 'src/app/user.model';
import { Subscription } from 'rxjs/internal/Subscription';
import { HttpClient } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';

import * as uploadresume from '../uploadresume/uploadresume.component'


@Component({
  selector: 'app-jobs',
  templateUrl: './jobs.component.html',
  styleUrls: ['./jobs.component.css']
})
export class JobsComponent implements OnInit {

  static readonly searchKey: string = "search"

  // /**
  //  * 實際User
  //  */
  // user: User|null = null;

  // private userSub: Subscription = this._userService.userBeSub.subscribe(u => {
  //   this.user = u
  // })

  // Subject jobsSub:sub
  isLoading: boolean = false

  constructor(
    private router:Router
    , private _utility: Utility
    , private _clipboard: Clipboard
    , private _modalService: BsModalService
    , private jobService: JobServiceService
    // , private _http:HttpClient
  ) {

  }

  /**
   * 外部輸入職缺(例如搜索或是其他條件後資料)
   */
  @Input() jobs: JobHttp[] | null = [];

  /**
   * 刪除event trigger (emitter)
   */
  @Output() jobsEvent = new EventEmitter<JobHttp>()
  /**
   * 是否有需要填入"預設"職缺
   */
  @Input() hasRecommend: boolean = false
  /** 
   * 是否為收藏名單
   */
  @Input() isFavo: boolean = false

  @Input() hideFavo: boolean = false
  @Input() hideJoin: boolean = false
  @Input() hideShare: boolean = false
  @Input() previewMode:boolean = false

  ngOnInit(): void {

  }

  isJobSaved(job: JobHttp): boolean {
    let savedJobsIds = JSON.parse(localStorage.getItem('jobs')!) || [];
    return savedJobsIds.includes(job.id);
}

  // 收藏 & 解除收藏
  jobsSaved(j: JobHttp) {
   
    if(this.previewMode) {
      return
    }

    this.jobService.onJobFavorited(j);

    
    this.jobsEvent.emit(j);

    let savedJobsIds = JSON.parse(localStorage.getItem('jobs')!) || [];

    this.updateSavedJobsCount(savedJobsIds.length);
  }

  modalRef?: BsModalRef;

  openModal(template: TemplateRef<any>, jobId: string) {

    if(this.previewMode) {
      return
    }
    
    this._clipboard.copy(`${this._utility.getFullUrlWithBaseHref()}${routesPath.job.path}/${routesPath.job.detail.path}/${jobId?.toString()}`)
    this.modalRef = this._modalService.show(template);
  }

  // 更新收藏職缺數量並通知NavbarComponent
  updateSavedJobsCount(count: number) {
    this.jobService.updateSavedJobsCount(count);
  }

  // 將職缺代碼帶去UploadResume
  sendResume(j: JobHttp){
    
    const o:any = {}
    o[uploadresume.UploadResumeComponent.key] = j.id
    
    const url =this.router.serializeUrl(this.router.createUrlTree(['UploadResume'],{queryParams:o}))
    
    window.open(`${this._utility.getHandleBaseHref()}${url}`)
  }

  openJob(j: JobHttp){
    // [routerLink]="previewMode?null:['/Jobs','Show',j.id]"
        
    const url =this.router.serializeUrl(this.router.createUrlTree(['Jobs/Show',j.id]))
    
    window.open(`${this._utility.getHandleBaseHref()}${url}`)
  }
}
