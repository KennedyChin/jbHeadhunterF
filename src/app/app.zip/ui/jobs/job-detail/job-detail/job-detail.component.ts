import { Component, EventEmitter, Input, OnInit, Output, TemplateRef } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { Clipboard } from '@angular/cdk/clipboard';
import { Observable, ReplaySubject, Subscription, tap } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxSpinnerService } from "ngx-spinner";

import { Utility } from '../../../utility';
import { JobServiceService } from 'src/app/services/job-service.service';
import { JobHttp } from 'src/app/share/Model/JobHttpDto';
import { MyServiceService } from 'src/app/services/my-service.service';
import { User } from 'src/app/user.model';
import { ToastrService } from 'ngx-toastr';
import * as uploadresume from '../../../uploadresume/uploadresume.component'


@Component({
  selector: 'app-job-detail',
  templateUrl: './job-detail.component.html',
  styleUrls: ['./job-detail.component.css']
})
export class JobDetailComponent implements OnInit {

  private sub: Subscription | null = null
  jobSub$ = new ReplaySubject<JobHttp>(1)
  job$: Observable<JobHttp> | null = null
  showMyresumeAlert: boolean = false
  error: boolean | null = null
  /**
   * 實際User
   */
  user: User | null = null;
  /**
   * 關閉相關按鈕功能(Event) for 預覽用
   */
  @Input() previewMode:boolean = false;

  /**
   * 刪除event trigger (emitter)
   */
  @Output() jobsEvent = new EventEmitter<JobHttp>()

  constructor(
    private route: ActivatedRoute
    , private router: Router
    , private _utility: Utility
    , private clipboard: Clipboard
    , private modalService: BsModalService
    , private spinner: NgxSpinnerService
    , private _jobService: JobServiceService
    , private myService: MyServiceService
    // ,private _http: HttpClient
    , private toastr: ToastrService
  ) {
    this.sub = this.route.params.subscribe(n => {
      this.spinner.show()
      const id: number = n["id"] as number
      _jobService.getJobDetail(id)
        .subscribe({
          next: n => {
            if (!!n)
              this.jobSub$.next(n)
          }, error: error => {
            this.router.navigate(["404"])
          }
        })
    })
  }

  /**
   * 收藏職缺
   * @param j 
   * @returns 
   */
  saveThisJob(j: JobHttp) {

    if(this.previewMode) {
      return
    }

    this._jobService.onJobFavorited(j);

    
    this.jobsEvent.emit(j);

    let savedJobsIds = JSON.parse(localStorage.getItem('jobs')!) || [];

    this.updateSavedJobsCount(savedJobsIds.length);
  }

  ngOnDestroy(): void {
    this.sub?.unsubscribe()
    this.jobSub$.unsubscribe()
  }

  ngOnInit(): void {
    // this.message = "<a routerLink=\"/user/bob\">link to user component</a>"
    // this.showMyresumeAlert = true
  }


  isJobSaved(job: JobHttp): boolean {
    let savedJobsIds = JSON.parse(localStorage.getItem('jobs')!) || [];
    return savedJobsIds.includes(job.id);
}
  modalRef?: BsModalRef;
  openModal(template: TemplateRef<any>, jobId: string) {

    if(this.previewMode) {
      return
    }

    const fullUrl: string = location.href
    this.clipboard.copy(fullUrl)
    this.modalRef = this.modalService.show(template);
  }
  
  // 更新收藏職缺數量並通知NavbarComponent
  updateSavedJobsCount(count: number) {
    this._jobService.updateSavedJobsCount(count);
  }
  
  // 將職缺代碼帶去UploadResume
  sendResume(j: JobHttp){
    
    const o:any = {}
    o[uploadresume.UploadResumeComponent.key] = j.id
    
    const url =this.router.serializeUrl(this.router.createUrlTree(['UploadResume'],{queryParams:o}))
    
    window.open(`${this._utility.getHandleBaseHref()}${url}`)
  }
}
