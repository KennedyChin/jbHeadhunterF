import { HttpClient } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
// import { ReCaptchaV3Service } from 'ng-recaptcha';
import { ToastrService } from 'ngx-toastr';
import { of, Subscription, tap } from 'rxjs';
import { filter } from 'rxjs/operators';
import { finalize } from 'rxjs/internal/operators/finalize';
import { ApiServiceService } from 'src/app/services/api-service.service';
import { DropdownSettings } from 'angular2-multiselect-dropdown/lib/multiselect.interface';
// import { ReCAPTCHAService } from 'src/app/services/re-captcha.service';

@Component({
  selector: 'app-subscribe',
  templateUrl: './subscribe.component.html',
  styleUrls: ['./subscribe.component.css']
})
export class SubscribeComponent implements OnInit  {

  


  isLoading: boolean = false
  // message: string = ""
  @ViewChild("f",{static:false}) f: NgForm | undefined

  areaDataList: {id: number, name: string, groupName: string}[] = [];
  areaSelectedItems: {id: number, name: string, groupName: string}[] = [{id: 0, name: '不拘', groupName: '無'}];

  areaDropSetting = {
    singleSelection: false,
    searchPlaceholderText: '搜尋區域關鍵字',
    text: "選擇區域",
    enableCheckAll:false,
    enableSearchFilter: true,
    labelKey: "name",
    primaryKey: "id",
    idField: "id",
    textField: "name",
    badgeShowLimit: 5,
    disabled:false,
    groupBy: "groupName"
  } as DropdownSettings

  postDataList: {id: number, name: string}[] = [];
  postSelectedItems: {id: number, name: string}[] = [{id: 0, name: '不拘'}];
  
  postDropSetting = {
    singleSelection: false,
    searchPlaceholderText: '搜尋職務關鍵字',
    text: "選擇職務",
    enableCheckAll:false,
    enableSearchFilter: true,    
    labelKey: "name",
    primaryKey: "id",
    idField: "id",
    textField: "name",
    badgeShowLimit: 5,
    disabled:false,
    selectionLimit:3
  } as DropdownSettings

  constructor(
    private router: Router
    ,private route: ActivatedRoute 
    ,private _http:HttpClient
    ,private toastr: ToastrService
    // ,private _recaptchaV3Service: ReCaptchaV3Service
    // ,private _recaptchaService:ReCAPTCHAService
    ,private _appService:ApiServiceService
    ) { 
      this.route.queryParams
      .pipe(filter(p=>p.message))
      .subscribe(params => {
        // this.message = params.message??"";
        this.toastr.info(params.message??'')
      })

    }

  ngOnInit(): void {
    // 將 dummyData 賦值給 multiselect 的 data 屬性
    this._http.get<{id: number, name: string, groupName: string}[]>('https://edc.jbhr.com.tw/FlyHigh/flyMe/Job/place').subscribe(data => {
      this.areaDataList = data.map(item => ({id: item.id, name: item.name, groupName: item.groupName}));
      this.areaSelectedItems=[{id:0, name:'不拘', groupName:'無'}];
      
    console.log(this.areaDataList)
    console.log(this.areaSelectedItems)
    }
    );
    // this.areaDataList = of(this._http.get('https://edc.jbhr.com.tw/FlyHigh/flyMe/Job/place'));

    this._http.get<{id: number, name: string}[]>('https://edc.jbhr.com.tw/FlyHigh/flyMe/Job/jobCategory').subscribe(data => {
      this.postDataList = data.map(item => ({id: item.id, name: item.name}));
      this.postSelectedItems=[{id:0, name:'不拘'}];
      
    console.log(this.postDataList)
    console.log(this.postSelectedItems)
    }
    );
    // this.postDataList=of(this._http.get('https://edc.jbhr.com.tw/FlyHigh/flyMe/Job/jobCategory'));

    // options: Option[] = [
    //   {
    //     id: 1,
    //     name: 'Option 1',
    //     subOptions: [
    //       { id: 11, name: 'Suboption 1-1', selected: false },
    //       { id: 12, name: 'Suboption 1-2', selected: false },
    //       { id: 13, name: 'Suboption 1-3', selected: false }
    //     ],
    //     selected: false
    //   },
    //   {
    //     id: 2,
    //     name: 'Option 2',
    //     subOptions: [
    //       { id: 21, name: 'Suboption 2-1', selected: false },
    //       { id: 22, name: 'Suboption 2-2', selected: false },
    //       { id: 23, name: 'Suboption 2-3', selected: false }
    //     ],
    //     selected: false
    //   }
    // ];
    
    // selectedOptions: Option[] = [];
    // this.multiselectSettings.data = this.dummyData;
  }


  private singleExecutionSubscription?: Subscription = undefined;
  recentToken = "";
  
  executeAction(action: string): void {
    if (this.singleExecutionSubscription) {
      this.singleExecutionSubscription.unsubscribe();
    }

    // this.singleExecutionSubscription = this._recaptchaService.executeAction(action).subscribe({
    //   next:token=>{
    //     this.recentToken = token;
    //     this.loginMe()
    //   },error:error=>{
    //     this.recentToken = "";
    //     this.toastr.error('reCAPTCHA error')
    //   }
    // })
    
    // this.singleExecutionSubscription = this._recaptchaV3Service.execute(action).subscribe(
    //   (token) => {
    //     this.recentToken = token;
    //     this.loginMe()
    //     // this.recentError = undefined;
    //   },
    //   (error) => {
    //     this.recentToken = "";
    //     this.toastr.error('reCAPTCHA error')
    //     // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
    //     // this.recentError = { error };
    //   }
    // )
  }

  isFieldValid(field: string) {
    //this.f?.control.get("password")
    return true
    //return !this.f?.control.get(field)?.valid && this.f?.control.get(field)?.touched;
  }
 
  loginMe() {

    if(!this.f?.valid){
      // this.message = "必填欄位未填寫"
      this.toastr.warning('必填欄位未填寫')
      return 
    }

    const f = this.f
    this.isLoading = true
    const account = f.value.account
    const password = f.value.password
  }

  // 訂閱
  subscribeNews(form: NgForm){

    console.log('test');

    // 姓名
    const username = form.value.username;
    // 郵件
    const usermail = form.value.usermail;

    const jobs = form.value.selectedPost;

    const places = form.value.selectedArea

    // Json格式
    const jsonBody = {
      "name": username,
      "email": usermail,
      "jobs": jobs,
      "places": places
    };

    const headers = { 'content-type': 'application/json' }

    if (form.valid) {
      // 表單驗證通過，可以提交表單

      const sendUserData$ = this._http.post(
        'https://edc.jbhr.com.tw/FlyHigh/flyMe/NewNewspaper/subscribe', jsonBody, { 'headers': headers })
        .pipe(finalize(()=>{}))
  
      sendUserData$.subscribe(n=>console.log(n))
  
      alert('訂閱完成');
  
      // 將使用者重新導回首頁
      window.location.href = 'https://edc.jbhr.com.tw/FlyHigh/web/'; // 將 URL 設為首頁的 URL

    } 
    else {
      // 表單驗證失敗，阻止提交表單
    }
  }


  onAreaItemSelect() {
    // 如果使用者選擇了任何項目，則移除"不拘"
    this.areaSelectedItems = this.areaSelectedItems.filter(item => item.id !== 0);
    // 最多只能選擇3個項目
    if (this.postSelectedItems.length > 3) {
      this.postSelectedItems.shift();
    }
  }
  
  onAreaItemDeselect() {
    // 如果使用者取消選擇了所有項目，則添加"不拘"
    if (this.areaSelectedItems.length === 0) {
      this.areaSelectedItems.push({id: 0, name: '不拘', groupName: "無"});
    }
  }
  
  onAreaSelectAll() {
    // 如果使用者選擇了所有項目，則移除"不拘"
    this.areaSelectedItems = this.areaSelectedItems.filter(item => item.id !== 0);
  }
  
  onAreaDeselectAll() {
    // 如果使用者取消選擇了所有項目，則添加"不拘"
    if (this.areaSelectedItems.length === 0) {
      this.areaSelectedItems.push({id: 0, name: '不拘', groupName: "無"});
    }
  }


  
  onPostItemSelect() {
    // 如果使用者選擇了任何項目，則移除"不拘"
    this.postSelectedItems = this.postSelectedItems.filter(item => item.id !== 0);
    // 最多只能選擇3個項目
    if (this.postSelectedItems.length > 3) {
      this.postSelectedItems.shift();
    }
  }
  
  onPostItemDeselect() {
    // 如果使用者取消選擇了所有項目，則添加"不拘"
    if (this.postSelectedItems.length === 0) {
      this.postSelectedItems.push({id: 0, name: '不拘'});
    }
  }
  
  onPostSelectAll() {
    // 如果使用者選擇了所有項目，則移除"不拘"
    this.postSelectedItems = this.postSelectedItems.filter(item => item.id !== 0);
    // 最多只能選擇3個項目
    if (this.postSelectedItems.length > 3) {
      this.postSelectedItems.splice(3, this.postSelectedItems.length - 3);
    }
  }
  
  onPostDeselectAll() {
    // 如果使用者取消選擇了所有項目，則添加"不拘"
    if (this.postSelectedItems.length === 0) {
      this.postSelectedItems.push({id: 0, name: '不拘'});
    }
  }
}
