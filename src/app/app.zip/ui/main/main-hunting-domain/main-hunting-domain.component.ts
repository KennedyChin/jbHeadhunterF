import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-main-hunting-domain',
  templateUrl: './main-hunting-domain.component.html',
  styleUrls: ['./main-hunting-domain.component.css']
})
export class MainHuntingDomainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
