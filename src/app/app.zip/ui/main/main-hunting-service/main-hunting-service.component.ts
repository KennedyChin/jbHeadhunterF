import { Component, OnInit } from '@angular/core';

/**
 * 首頁Section
 */
@Component({
  selector: 'app-main-hunting-service',
  templateUrl: './main-hunting-service.component.html',
  styleUrls: ['./main-hunting-service.component.css']
})
export class MainHuntingServiceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
