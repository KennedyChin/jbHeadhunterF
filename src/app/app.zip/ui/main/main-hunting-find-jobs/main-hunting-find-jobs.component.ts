import { Location } from '@angular/common';
import { Component, Inject, Injector, OnInit } from '@angular/core';
import { NgForm, NgModel } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Utility } from '../../utility';
import { JobsComponent } from '../../jobs/jobs.component';
import { HttpClient } from '@angular/common/http';

import * as Job from '../../jobs/jobs.component'


@Component({
  selector: 'app-main-hunting-find-jobs',
  templateUrl: './main-hunting-find-jobs.component.html',
  styleUrls: ['./main-hunting-find-jobs.component.css']
})

export class MainHuntingFindJobsComponent implements OnInit {
  searchText:string|null = null
  selectedPlaceItem:number = 0
  selectedJobItem:number = 0

  selectedPlace: string = '';
  selectedJob: string = '';

  places!: any[]
  jobs!: any[]

  constructor(
    private router:Router
    ,private _router:Router
    ,private route:ActivatedRoute
    ,private _route:ActivatedRoute
    ,private location:Location
    ,private utility:Utility
    ,private http: HttpClient
  ) { }

  ngOnInit(): void {
    
    // 在初始化 Component 時呼叫 API 取得地區資料
    this.http.get<any[]>('https://edc.jbhr.com.tw/FlyHigh/flyMe/Job/place').subscribe(n => this.places = n);
    this.http.get<any[]>('https://edc.jbhr.com.tw/FlyHigh/flyMe/Job/jobCategory').subscribe(n => this.jobs = n);

    
  }

  // findJobs(t:NgModel){
    
  //   const v:string = t.value ? t.value : " ";

  //   let selectedPlaceName = this.places.find(p => p.id === Number(this.selectedPlace))?.name 
  //   ? this.places.find(p => p.id === Number(this.selectedPlace))?.name===undefined : "";

  //   let selectedJobName = this.jobs.find(p => p.id === Number(this.selectedJob))?.name
  //   ? this.jobs.find(p => p.id === Number(this.selectedJob))?.name===undefined : "";
    
  //   const o:any = {}
  //   o[Job.JobsComponent.searchKey] = v
  //   o.hasingKey=new Date().getTime()
      
  //   const url =this.router.serializeUrl(this.router.createUrlTree(['Jobs'],{queryParams:o,queryParamsHandling:'merge'}))
    
  //   window.open(`${this.utility.getHandleBaseHref()}${url}`)
  // }

  findJobs(f:NgForm){
    
    const v:string = f.value.search ? f.value.search : " ";

    const selectedPlaceId = f.value.selectedPlace;
    const selectedJobId = f.value.selectedJob;
  
    const queryParams: any = {
      placeId: selectedPlaceId,
      jobId: selectedJobId,
      [Job.JobsComponent.searchKey]: v,
      hasingKey: new Date().getTime(),
    };
  
    const url = this.router.serializeUrl(this.router.createUrlTree(['Jobs'],{queryParams:queryParams,queryParamsHandling:'merge'}))
    // window.open(`${this.utility.getHandleBaseHref()}${url}`);
    this.router.navigateByUrl(url);
  }

}
