import { Component, Input, OnInit } from '@angular/core';
import { Observable, shareReplay } from 'rxjs';
import { JobServiceService } from 'src/app/services/job-service.service';
import { environment } from 'src/environments/environment';
import { JobHttp } from '../../../share/Model/JobHttpDto';

@Component({
  selector: 'app-main-hunting-introduction',
  templateUrl: './main-hunting-introduction.component.html',
  styleUrls: ['./main-hunting-introduction.component.css']
})
export class MainHuntingIntroductionComponent implements OnInit {

  @Input() jobs:JobHttp[] | null = null
  jobs$?:Observable<JobHttp[]>
  static readonly imageRoot:string =   environment.hotJobImagePath

  constructor(
    private jobService:JobServiceService
  ) { }

  ngOnInit(): void {
    
  }


}
