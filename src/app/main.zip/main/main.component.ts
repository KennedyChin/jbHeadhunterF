
import { Component, OnDestroy, OnInit } from '@angular/core';
import { Observable, of } from 'rxjs';
import { filter, switchMap } from 'rxjs/operators';

// import { appInputFocusWithFormGroup} from '../share/inputFocusWithLabel'
import { JobServiceService } from '../services/job-service.service';
import { JobHttp } from '../share/Model/JobHttpDto';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit{

  regions:string[]=[];
  toDoActionJobs:JobHttp[] = []
  message:string = "";

  constructor(private jobService:JobServiceService) {}

  ngOnInit(): void {
    // this.bindMe();
  }
  
  // searchMe(m:HTMLInputElement) {
  //   const text:string = m.value??"";
    
  //   // TODO: 1/4 修改範疇
  //   // if(text.length<2) {
  //   //   alert("內容長度最小為2字元")
  //   //   return
  //   // }

  //   of(text).pipe(
  //       switchMap(t=>
  //         {
  //           const len = t.length


  //           const placeId = 0; 
  //           const jobId = 0; 
  //           return len>0 ? this.jobService.getSearchJobs(placeId, jobId, t) : this.jobService.getActiveJobs()


  //           // return len>0 ? this.jobService.getSearchJobs(t) : this.jobService.getActiveJobs()
  //           // return this.jobService.getSearchJobs(t)
  //         }
  //       )
  //     ,).subscribe(n=>{
  //       this.toDoActionJobs.splice(0,this.toDoActionJobs.length)
  //       this.toDoActionJobs.push(...n)
  //       // TODO: 之後將其移除將其畫面固定到顯示職缺區塊
  //       let x = (<HTMLBaseElement>document.querySelector("#tagToJob"))
  //       let fixEle = (<HTMLBaseElement>document.querySelector("#header"))
        
  //       if (x && fixEle){
  //           window.scroll({top:x.offsetTop-(fixEle.offsetHeight*2),behavior:"smooth"})
  //       }
  //     });
  // }
}
